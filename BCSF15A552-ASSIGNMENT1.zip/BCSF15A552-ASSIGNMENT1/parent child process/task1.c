#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
int main() {
	
	//Sum of first 1000 natural numbers (1-1000)
	int totalSum = 0;

	int array[1000];
	int level = 0,fd[2],sum = 0;
	int i,j;
	for (i = 0; i < 1000; ++i)
	{
		array[i] = i+1;
	}	
	for (j = 0; j < 1000; ++j)
	{	
		if(j%100 == 0)
		{
			// creating pipe descriptors
			pipe(fd);
			level++;
			sum = 0;
			// fork() returns 0 for child process, child-pid for parent process.
			pid_t cpid = fork();
			if (cpid == 0) {
				// Child's Code
				
				close(fd[0]);
				for (int i = j; i < j+100; ++i)
				{
					sum += array[i];
				}
				write(fd[1], &sum, sizeof(sum));
				
				printf("Process %d sent sum of %d to %d : %d \n",level,j+1,j+100, sum);
				
				// closing the write descriptor of child
				close(fd[1]);
				//killing the child process so it won't run more than this
				kill(getpid(), SIGKILL);
			}
			else 
			{
				// closing the write-descriptor of parent
				close(fd[1]);
				wait(NULL);

				// reading the data received by child
				read(fd[0], &sum, sizeof(sum));
				totalSum = totalSum + sum;
				
//				printf("Parent received %d Sum at %d Level\n\n", sum, level);

				// closing the read-descriptor of parent
				close(fd[0]);
			}
		}
	}
	printf("\nTotal Sum (1-1000) calculated by adding all = %d\n", totalSum);
	printf("\n");
	return 0;
}
